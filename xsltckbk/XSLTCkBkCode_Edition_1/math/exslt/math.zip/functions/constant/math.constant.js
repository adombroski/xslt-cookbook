function E(){ return Math.E;}

function LN2(){ return Math.LN2;}

function LN10(){ return Math.LN10;}

function LOG2E(){ return Math.LOG2E;}

function LOG10E(){ return Math.LOG10E;}

function PI(){ return Math.PI;}

function SQRT1_2(){ return Math.SQRT1_2;}

function SQRT2(){ return Math.SQRT2;}

